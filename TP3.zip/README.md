# TP3

TP3 de la materia **Testing de Software en Sistemas Embebidos**, CESE.

Para correr los tests: `ceedling test:all`
# SOPG_TP3
